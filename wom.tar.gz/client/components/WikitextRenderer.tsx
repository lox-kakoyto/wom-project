
import React, { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  ChevronRight, AlertTriangle, Info, CheckCircle, XCircle, 
  Box, Shield, Zap, Skull, Crown, ChevronDown, 
  Image as ImageIcon, Music, Trophy, MinusCircle, X,
  Folder, Layers, Monitor, Disc, Play, Pause, Volume2
} from 'lucide-react';
import { MediaItem } from '../types';

/* ============================================================================
   HELPERS & PARSERS
   ============================================================================ */

export function findMediaUrl(filename: string, mediaFiles: MediaItem[]) {
    if (!filename) return '';
    if (filename.startsWith('http')) return filename; 
    const cleanName = filename.replace(/[[\]]/g, '').replace('File:', '').trim();
    const found = mediaFiles.find(m => m.filename === cleanName);
    return found ? found.url : 'https://via.placeholder.com/300?text=File+Not+Found';
}

/**
 * Robust Argument Parser that respects nested braces {{ }} and brackets [[ ]]
 */
export function parseArgs(inner: string) {
    const parts: string[] = [];
    let currentPart = '';
    let braceDepth = 0;
    let bracketDepth = 0;

    for (let i = 0; i < inner.length; i++) {
        const char = inner[i];
        
        if (char === '{' && inner[i+1] === '{') {
            braceDepth++;
            currentPart += '{';
        } else if (char === '}' && inner[i+1] === '}') {
            braceDepth--;
            currentPart += '}';
        } else if (char === '[' && inner[i+1] === '[') {
            bracketDepth++;
            currentPart += '[';
        } else if (char === ']' && inner[i+1] === ']') {
            bracketDepth--;
            currentPart += ']';
        } else if (char === '|' && braceDepth === 0 && bracketDepth === 0) {
            parts.push(currentPart.trim());
            currentPart = '';
            continue;
        } else {
            currentPart += char;
        }
    }
    if (currentPart) parts.push(currentPart.trim());

    const args: Record<string, string> = {};
    parts.forEach((part, index) => {
        if (index === 0) return; // Template Name
        
        const eqIndex = part.indexOf('=');
        if (eqIndex > -1) {
            const key = part.substring(0, eqIndex).trim();
            const val = part.substring(eqIndex + 1).trim();
            args[key] = val;
        } else {
            args[index] = part.trim();
        }
    });
    return { parts, args };
}

/**
 * Extracts a balanced template from a string start
 */
function extractBalancedTemplate(str: string, startIndex: number): string | null {
    let depth = 0;
    for (let i = startIndex; i < str.length; i++) {
        if (str[i] === '{' && str[i+1] === '{') {
            depth++;
            i++;
        } else if (str[i] === '}' && str[i+1] === '}') {
            depth--;
            i++;
            if (depth === 0) return str.substring(startIndex, i + 1);
        }
    }
    return null;
}

export function parseInfobox(content: string, mediaFiles: MediaItem[]) {
  const infoboxStart = content.indexOf('{{Infobox');
  if (infoboxStart === -1) return null;

  const fullTemplate = extractBalancedTemplate(content, infoboxStart);
  if (!fullTemplate) return null;

  const inner = fullTemplate.slice(9, -2); // Remove {{Infobox and }}
  const { args } = parseArgs(inner);
  
  const imgKey = Object.keys(args).find(k => k.toLowerCase() === 'image');
  if (imgKey) {
     let val = args[imgKey];
     val = val.replace(/[[\]]/g, '');
     args['image'] = findMediaUrl(val, mediaFiles);
  }

  return Object.keys(args).length > 0 ? args : null;
}

/* ============================================================================
   SUB-COMPONENTS
   ============================================================================ */

const MarkdownBlock: React.FC<{ text: string, mediaFiles: MediaItem[] }> = ({ text, mediaFiles }) => {
    const hasBlockElements = text.includes('\n') || text.includes('==') || text.startsWith('* ');

    const processInline = (str: string) => {
        const boldParts = str.split("'''");
        return boldParts.map((part, idx) => {
             if (idx % 2 === 1) return <b key={`b-${idx}`} className="text-white font-bold">{part}</b>;
             
             const italicParts = part.split("''");
             return italicParts.map((ip, idx2) => {
                 if (idx2 % 2 === 1) return <i key={`i-${idx}-${idx2}`} className="text-gray-300 italic">{ip}</i>;
                 
                 const linkParts = ip.split(/(\[\[.*?\]\])/g);
                 return linkParts.map((lp, idx3) => {
                     if (lp.startsWith('[[') && lp.endsWith(']]')) {
                         const content = lp.slice(2, -2);
                         const [target, label] = content.split('|');
                         if(target.startsWith('File:')) return null; 
                         return (
                             <Link key={idx3} to={`/wiki/${target.toLowerCase().replace(/ /g, '-')}`} className="text-wom-primary hover:text-white hover:underline transition-colors">
                                 {label || target}
                             </Link>
                         );
                     }
                     return lp;
                 });
             });
        });
    };

    if (!hasBlockElements) {
        // Essential for gradients: span must be inline to flow correctly
        return <span className="text-gray-300 leading-relaxed text-sm md:text-base align-baseline">{processInline(text)}</span>;
    }

    const lines = text.split('\n');
    return (
        <>
            {lines.map((line, i) => {
                if (line.startsWith('== ') && line.endsWith(' ==')) return <h2 key={i} className="text-2xl font-bold text-white border-b-2 border-wom-primary/50 pb-1 mb-4 mt-8 uppercase tracking-wide clear-both">{line.replace(/==/g, '').trim()}</h2>;
                if (line.startsWith('=== ') && line.endsWith(' ===')) return <h3 key={i} className="text-xl font-bold text-wom-accent mb-2 mt-4 clear-both">{line.replace(/===/g, '').trim()}</h3>;
                if (line.startsWith('----')) return <hr key={i} className="border-t border-white/20 my-6 clear-both" />;

                if (line.trim() === '') return <br key={i}/>;

                if (line.startsWith('* ')) {
                    return <li key={i} className="ml-4 text-gray-300 list-disc marker:text-wom-primary mb-1">
                        {processInline(line.replace('* ', ''))}
                    </li>
                }

                return <p key={i} className="mb-2 text-gray-300 leading-relaxed text-sm md:text-base">
                    {processInline(line)}
                </p>;
            })}
        </>
    )
}

/* --- TABBER (4 Styles) --- */
const TabberComponent: React.FC<{ 
    tabs: {title: string, content: string}[], 
    mediaFiles: MediaItem[], 
    style?: string, 
    width?: string, 
    height?: string 
}> = ({ tabs, mediaFiles, style = 'classic', width, height }) => {
    const [activeTab, setActiveTab] = useState(0);
    if (tabs.length === 0) return null;

    // Styles configuration
    const styles: Record<string, any> = {
        classic: {
            container: "border border-white/10 bg-black/40 rounded-lg overflow-hidden",
            nav: "bg-white/5 border-b border-white/10 flex overflow-x-auto",
            btnActive: "bg-wom-primary text-white border-b-2 border-white font-bold",
            btnInactive: "text-gray-400 hover:bg-white/10 hover:text-white",
            content: "p-4",
            icon: <Layers size={14} className="inline mr-2" />
        },
        cyberpunk: {
            container: "border-2 border-wom-accent/50 bg-[#050308] shadow-[0_0_15px_rgba(217,70,239,0.2)] skew-x-[-2deg]",
            nav: "flex border-b-2 border-wom-accent/30 bg-black overflow-x-auto",
            btnActive: "bg-wom-accent text-black font-black uppercase tracking-widest clip-path-slant",
            btnInactive: "text-wom-accent font-bold uppercase tracking-widest hover:text-white hover:bg-wom-accent/20",
            content: "p-6 relative bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] skew-x-[2deg]",
            icon: <Monitor size={14} className="inline mr-2" />
        },
        folder: {
            container: "mt-2 pt-2",
            nav: "flex space-x-1 px-2 overflow-x-auto",
            btnActive: "bg-wom-panel text-white rounded-t-lg border-t border-x border-white/20 mb-[-1px] pb-2 pt-2 px-4 z-10 font-bold shadow-[0_-5px_10px_rgba(0,0,0,0.5)]",
            btnInactive: "bg-white/5 text-gray-500 rounded-t-lg border-t border-x border-transparent hover:bg-white/10 pb-2 pt-2 px-4",
            content: "bg-wom-panel border border-white/20 rounded-b-lg rounded-tr-lg p-4 relative z-0 shadow-lg",
            icon: <Folder size={14} className="inline mr-2" />
        },
        pills: {
            container: "bg-transparent",
            nav: "flex space-x-2 bg-black/30 p-1 rounded-full w-fit mb-4 mx-auto border border-white/10 overflow-x-auto max-w-full",
            btnActive: "bg-wom-primary text-white shadow-lg rounded-full font-bold px-6",
            btnInactive: "text-gray-400 hover:text-white rounded-full hover:bg-white/5 px-4",
            content: "bg-wom-panel/50 border border-white/5 rounded-2xl p-6 shadow-xl backdrop-blur-sm",
            icon: <Box size={14} className="inline mr-2" />
        }
    };

    const currentStyle = styles[style] || styles.classic;

    return (
        <div className={`my-6 flow-root clear-both`} style={{ width: width || '100%' }}>
            <div className={currentStyle.container}>
                <div className={`custom-scrollbar ${currentStyle.nav}`}>
                    {tabs.map((tab, i) => (
                        <button
                            key={i}
                            onClick={() => setActiveTab(i)}
                            className={`px-4 py-3 text-sm transition-all whitespace-nowrap flex items-center justify-center ${
                                activeTab === i ? currentStyle.btnActive : currentStyle.btnInactive
                            }`}
                        >
                            {activeTab === i && currentStyle.icon}
                            {tab.title}
                        </button>
                    ))}
                </div>
                <div className={`${currentStyle.content}`} style={{ minHeight: height || 'auto' }}>
                    <div className="animate-fade-in">
                        <WikitextRenderer content={tabs[activeTab].content} mediaFiles={mediaFiles} />
                    </div>
                </div>
            </div>
        </div>
    );
};

/* --- MUSIC TABBER --- */
const MusicTabber: React.FC<{ tracks: {title: string, url: string}[], style?: string }> = ({ tracks, style }) => {
    const [currentTrack, setCurrentTrack] = useState(0);
    const audioRef = React.useRef<HTMLAudioElement>(null);

    const playTrack = (index: number) => {
        setCurrentTrack(index);
        if(audioRef.current) {
            audioRef.current.load();
            audioRef.current.play().catch(e => console.log("Auto-play blocked", e));
        }
    };
    
    return (
        <div className="my-6 border border-wom-primary/30 rounded-xl overflow-hidden bg-black/80 shadow-[0_0_20px_rgba(168,85,247,0.15)] clear-both max-w-lg mx-auto md:float-right md:ml-6 md:w-80">
            {/* Header */}
            <div className="bg-gradient-to-r from-wom-primary/20 to-wom-accent/10 p-3 border-b border-wom-primary/20 flex items-center justify-between backdrop-blur-md">
                <span className="text-xs font-bold text-wom-primary uppercase tracking-widest flex items-center gap-2">
                    <Music size={14} /> Musikbox
                </span>
                <div className="flex gap-1">
                    <div className="w-2 h-2 rounded-full bg-red-500"></div>
                    <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                    <div className="w-2 h-2 rounded-full bg-green-500"></div>
                </div>
            </div>
            
            <div className="p-6 flex flex-col items-center text-center relative overflow-hidden">
                {/* Visualizer Background Effect */}
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20 animate-pulse-slow pointer-events-none"></div>

                <div className="w-32 h-32 rounded-full border-4 border-wom-primary/30 p-1 mb-4 relative group">
                     <div className="w-full h-full rounded-full bg-gradient-to-br from-wom-primary to-wom-accent flex items-center justify-center overflow-hidden shadow-inner relative z-10 animate-[spin_10s_linear_infinite]">
                         <Disc size={64} className="text-white opacity-80" />
                     </div>
                     <div className="absolute inset-0 rounded-full border border-wom-accent animate-ping opacity-20"></div>
                </div>

                <h3 className="font-bold text-white text-lg mb-1 truncate w-full">{tracks[currentTrack]?.title || 'Select Track'}</h3>
                <p className="text-xs text-wom-primary mb-6 uppercase tracking-wider">Now Playing</p>
                
                <audio 
                    ref={audioRef}
                    controls 
                    src={tracks[currentTrack]?.url} 
                    className="w-full h-8 mb-6 filter invert opacity-80" 
                />

                <div className="w-full space-y-2 max-h-40 overflow-y-auto custom-scrollbar pr-2">
                    {tracks.map((t, i) => (
                        <button 
                            key={i}
                            onClick={() => playTrack(i)}
                            className={`w-full text-left px-3 py-2 rounded text-xs font-bold transition-all flex justify-between items-center ${
                                currentTrack === i 
                                ? 'bg-wom-primary text-white shadow-lg' 
                                : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
                            }`}
                        >
                            <span className="truncate">{i + 1}. {t.title}</span>
                            {currentTrack === i && <Music size={10} className="animate-bounce" />}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
}

/* --- COMPACT AUDIO (New Type) --- */
const CompactAudio: React.FC<{ file: string, align: string }> = ({ file, align }) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const audioRef = useRef<HTMLAudioElement>(null);

    const togglePlay = () => {
        if (!audioRef.current) return;
        if (isPlaying) {
            audioRef.current.pause();
        } else {
            audioRef.current.play();
        }
        setIsPlaying(!isPlaying);
    };

    let floatClass = 'float-right ml-6 mb-4';
    if (align === 'left') floatClass = 'float-left mr-6 mb-4';
    if (align === 'center') floatClass = 'float-none mx-auto block mb-6 clear-both';

    return (
        <div className={`${floatClass} w-[300px] max-w-full -mt-5 relative z-20`}>
             <div className="bg-[#151515] border border-white/10 rounded-b-lg p-2 flex items-center gap-3 shadow-lg">
                <button 
                    onClick={togglePlay}
                    className="w-8 h-8 rounded-full bg-wom-primary flex items-center justify-center text-white hover:bg-wom-accent transition-colors shrink-0"
                >
                    {isPlaying ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" className="ml-0.5" />}
                </button>
                <div className="flex-1 min-w-0">
                    <div className="text-[10px] text-gray-400 uppercase tracking-wider font-bold truncate">Attached Audio</div>
                    <div className="h-1 bg-gray-700 rounded-full mt-1 overflow-hidden">
                        <div className={`h-full bg-wom-primary ${isPlaying ? 'animate-[shimmer_2s_infinite]' : ''} w-full`}></div>
                    </div>
                </div>
                <Volume2 size={16} className="text-gray-500" />
                <audio ref={audioRef} src={file} onEnded={() => setIsPlaying(false)} />
             </div>
        </div>
    );
};

/* --- BATTLE RESULTS --- */
const BattleResults: React.FC<{ 
    wins: string, 
    draws: string, 
    losses: string, 
    style?: string,
    borderColor?: string,
    textColor?: string,
    bgColor?: string,
    mediaFiles: MediaItem[]
}> = ({ wins, draws, losses, style = 'classic', borderColor, textColor, bgColor, mediaFiles }) => {
    
    // Default colors if not provided
    const bd = borderColor || '#ffffff1a'; // white/10
    const txt = textColor || '#e5e7eb'; // gray-200
    const bg = bgColor || '#00000066'; // black/40

    const renderBlock = (title: string, content: string, icon: React.ReactNode, colorClass: string, bgClass: string) => (
        <div className={`flex-1 min-w-[120px] h-full ${bgClass} rounded-lg p-4 border border-white/5`}>
            <div className={`text-xs font-black uppercase tracking-widest mb-3 flex items-center justify-center gap-2 border-b border-white/10 pb-2 ${colorClass}`}>
                {icon} {title}
            </div>
            <div className="text-sm leading-relaxed text-center" style={{ color: txt }}>
                 <WikitextRenderer content={content || '-'} mediaFiles={mediaFiles} />
            </div>
        </div>
    );

    if (style === 'cards') {
        return (
            <div className="my-8 clear-both">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {renderBlock('Victories', wins, <Trophy size={16} />, 'text-green-400', 'bg-green-900/20')}
                    {renderBlock('Draws', draws, <MinusCircle size={16} />, 'text-yellow-400', 'bg-yellow-900/20')}
                    {renderBlock('Defeats', losses, <X size={16} />, 'text-red-400', 'bg-red-900/20')}
                </div>
                <div className="text-[10px] text-center mt-2 text-gray-600 uppercase tracking-widest">Battle Record</div>
            </div>
        )
    }

    if (style === 'compact') {
        return (
             <div className="my-6 border-l-4 border-wom-primary bg-white/5 p-4 rounded-r-lg clear-both shadow-lg" style={{ backgroundColor: bg }}>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-6 divide-y md:divide-y-0 md:divide-x divide-white/10">
                    <div className="px-2">
                        <span className="text-green-400 font-bold text-xs uppercase block mb-1">Wins</span>
                        <div style={{ color: txt }}><WikitextRenderer content={wins || '-'} mediaFiles={mediaFiles} /></div>
                    </div>
                    <div className="px-2 pt-4 md:pt-0">
                        <span className="text-yellow-400 font-bold text-xs uppercase block mb-1">Draws</span>
                        <div style={{ color: txt }}><WikitextRenderer content={draws || '-'} mediaFiles={mediaFiles} /></div>
                    </div>
                    <div className="px-2 pt-4 md:pt-0">
                        <span className="text-red-400 font-bold text-xs uppercase block mb-1">Losses</span>
                        <div style={{ color: txt }}><WikitextRenderer content={losses || '-'} mediaFiles={mediaFiles} /></div>
                    </div>
                 </div>
             </div>
        )
    }

    // Classic Table Style
    return (
        <div className="my-8 border rounded-xl overflow-hidden clear-both shadow-lg" style={{ borderColor: bd, backgroundColor: bg }}>
            <div className="bg-white/5 p-2 text-center text-xs font-bold uppercase tracking-widest text-gray-500 border-b" style={{ borderColor: bd }}>
                Coliseum Record
            </div>
            <div className="grid grid-cols-3 text-center border-b" style={{ borderColor: bd, backgroundColor: 'rgba(255,255,255,0.02)' }}>
                <div className="p-3 font-black uppercase text-xs text-green-400 border-r tracking-wider" style={{ borderColor: bd }}>Wins</div>
                <div className="p-3 font-black uppercase text-xs text-yellow-400 border-r tracking-wider" style={{ borderColor: bd }}>Draws</div>
                <div className="p-3 font-black uppercase text-xs text-red-400 tracking-wider">Losses</div>
            </div>
            <div className="grid grid-cols-3 divide-x" style={{ borderColor: bd }}>
                <div className="p-4 text-center text-sm" style={{ color: txt }}><WikitextRenderer content={wins || '-'} mediaFiles={mediaFiles} /></div>
                <div className="p-4 text-center text-sm" style={{ color: txt }}><WikitextRenderer content={draws || '-'} mediaFiles={mediaFiles} /></div>
                <div className="p-4 text-center text-sm" style={{ color: txt }}><WikitextRenderer content={losses || '-'} mediaFiles={mediaFiles} /></div>
            </div>
        </div>
    );
}

/* ============================================================================
   MAIN RENDERER
   ============================================================================ */

export function WikitextRenderer({ content, mediaFiles }: { content: string, mediaFiles: MediaItem[] }) {
  
  let cleanContent = content;
  const infoboxMatch = content.match(/{{Infobox[\s\S]*?}}/i);
  if (infoboxMatch && infoboxMatch.index !== undefined && infoboxMatch.index < 50) {
      cleanContent = content.replace(infoboxMatch[0], '').trim();
  }

  // Robust Splitter
  const parts: string[] = [];
  let currentStr = '';
  let braceDepth = 0;

  for (let i = 0; i < cleanContent.length; i++) {
      const char = cleanContent[i];
      const nextChar = cleanContent[i+1];

      if (char === '{' && nextChar === '{') {
          if (braceDepth === 0 && currentStr) {
              parts.push(currentStr);
              currentStr = '';
          }
          braceDepth++;
          currentStr += '{{';
          i++; 
      } else if (char === '}' && nextChar === '}') {
          currentStr += '}}';
          braceDepth--;
          i++; 
          if (braceDepth === 0) {
              parts.push(currentStr);
              currentStr = '';
          }
      } else {
          currentStr += char;
      }
  }
  if (currentStr) parts.push(currentStr);

  return (
    <div className="prose prose-invert prose-purple max-w-none text-gray-300">
      {parts.map((part, index) => {
        if (part.startsWith('{{') && part.endsWith('}}')) {
           const inner = part.slice(2, -2);
           const { parts: splitParts, args } = parseArgs(inner);
           const templateName = splitParts[0].trim();
           
           /* --- MEDIA TEMPLATES (IMG2, GIF, Video) --- */
           if (['IMG2', 'GIF', 'Video'].includes(templateName)) {
               const filename = splitParts[1]?.trim();
               const isVideo = templateName === 'Video';
               let align = 'right';
               let width = '300px';

               for (let i = 2; i < splitParts.length; i++) {
                   const arg = splitParts[i].trim().toLowerCase().replace(']]', ''); 
                   if (['left', 'right', 'center'].includes(arg)) {
                       align = arg;
                   } else if (arg.endsWith('px') || arg.endsWith('%')) {
                       width = splitParts[i].trim().replace(']]', '');
                   }
               }
               const url = findMediaUrl(filename, mediaFiles);
               
               let floatClass = 'float-right ml-6 mb-4';
               if (align === 'left') floatClass = 'float-left mr-6 mb-4';
               if (align === 'center') floatClass = 'float-none mx-auto block mb-6 clear-both';

               return (
                   <div key={index} className={`${floatClass} relative group z-10`} style={{ width: width, maxWidth: '100%' }}>
                       {/* RESTORED FRAME: Stylish Container */}
                       <div className="p-1.5 bg-[#151515] border border-white/10 rounded-lg shadow-2xl relative z-20">
                           <div className="rounded overflow-hidden bg-black border border-white/5 relative">
                                {isVideo ? (
                                    <video src={url} controls className="w-full h-auto" />
                                ) : (
                                    <img src={url} alt={filename} className="w-full h-auto object-contain max-h-[600px]" />
                                )}
                                {/* Corner Accents */}
                                <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-wom-primary opacity-50"></div>
                                <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-wom-primary opacity-50"></div>
                           </div>
                       </div>
                   </div>
               );
           }
           
           /* --- COMPACT AUDIO PLAYER --- */
           if (templateName === 'CompactAudio') {
               const file = findMediaUrl(args['1'] || splitParts[1], mediaFiles);
               const align = args['align'] || 'center';
               return <CompactAudio key={index} file={file} align={align} />;
           }

           if (templateName === 'HoverImage') {
               const img1 = findMediaUrl(args['1'] || splitParts[1], mediaFiles);
               const img2 = findMediaUrl(args['2'] || splitParts[2], mediaFiles);
               const width = args['width'] || '300px';
               const align = args['align'] || 'right';

               let floatClass = 'float-right ml-6 mb-4';
               if (align === 'left') floatClass = 'float-left mr-6 mb-4';
               if (align === 'center') floatClass = 'float-none mx-auto block mb-6 clear-both';

               return (
                   <div key={index} className={`${floatClass} relative group overflow-hidden rounded bg-black z-10 border-2 border-white/10 p-1 bg-black/40 shadow-lg`} style={{ width: width, maxWidth: '100%' }}>
                       <img src={img1} className="w-full h-auto object-cover transition-opacity duration-300 group-hover:opacity-0 rounded-sm" alt="Base" />
                       <img src={img2} className="w-full h-auto object-cover absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100 rounded-sm m-1" alt="Hover" />
                   </div>
               );
           }

           /* --- TEXT & DECORATION --- */

           if (templateName === 'Color' || templateName === 'Gradient') {
                const text = args['1'] || splitParts[1] || 'Text';
                const color1 = args['2'] || splitParts[2] || '#fff';
                const color2 = args['3'] || splitParts[3]; // Optional second color for gradient
                
                const style: React.CSSProperties = {
                     fontWeight: 'bold',
                     display: 'inline', // Critical for text flow
                     WebkitBoxDecorationBreak: 'clone',
                     boxDecorationBreak: 'clone',
                };

                if (color2) {
                     style.background = `linear-gradient(to right, ${color1}, ${color2})`;
                     style.WebkitBackgroundClip = 'text';
                     style.backgroundClip = 'text';
                     style.color = 'transparent';
                } else {
                     style.color = color1;
                }

                return (
                    <span key={index} style={style}>
                        {text}
                    </span>
                );
           }

           /* --- FURIGANA (RUBY) --- */
           if (templateName === 'Ruby' || templateName === 'Furigana') {
               const base = args['1'] || splitParts[1] || 'Base';
               const top = args['2'] || splitParts[2] || 'Top';
               const color = args['color'] || '#a855f7';
               const size = args['size'] || '50%';
               const bold = args['bold'] === 'true' ? 'bold' : 'normal';

               return (
                   <ruby key={index} className="group mx-1">
                       {base}
                       <rt style={{ 
                           color: color, 
                           fontSize: size, 
                           fontWeight: bold,
                           userSelect: 'none'
                        }}>
                            {top}
                        </rt>
                   </ruby>
               );
           }

           /* --- TABBER (Rewritten) --- */

           if (templateName === 'Tabber') {
               const tabs: {title: string, content: string}[] = [];
               const width = args['width'];
               const height = args['height'];
               const style = args['style'] || 'classic'; 

               Object.keys(args).forEach(key => {
                   if (['width', 'height', 'style'].includes(key)) return;
                   if (isNaN(parseInt(key))) {
                       tabs.push({ title: key, content: args[key] });
                   }
               });
               
               return <TabberComponent key={index} tabs={tabs} mediaFiles={mediaFiles} width={width} height={height} style={style} />;
           }

           /* --- UNIVERSAL SPOILER BLOCK --- */
           if (templateName === 'SpoilerBlock') {
               const align = args['align'] || args['Расположение'] || 'center';
               const bg = args['bg'] || args['Код цвета фона'] || 'transparent';
               const color = args['color'] || args['Код цвета текста'] || '#e5e7eb';
               const openText = args['title'] || args['Открытое'] || 'Open';
               const closedContent = args['content'] || args['Закрытое'] || '';
               const border = args['border'] || args['Обводка'] || 'transparent';

               const alignmentClass = align === 'center' ? 'mx-auto' : align === 'left' ? 'mr-auto' : 'ml-auto';

               return (
                   <details key={index} className={`my-4 max-w-2xl ${alignmentClass} group rounded-lg overflow-hidden border transition-all duration-300 open:bg-black/20`} style={{ backgroundColor: bg, borderColor: border }}>
                       <summary 
                          className="cursor-pointer p-3 font-bold text-center list-none select-none hover:opacity-80 transition-opacity flex items-center justify-center gap-2"
                          style={{ color: color }}
                        >
                            <span className="group-open:rotate-90 transition-transform duration-200"><ChevronRight size={14} /></span>
                            <WikitextRenderer content={openText} mediaFiles={mediaFiles} />
                       </summary>
                       <div className="p-4 border-t border-white/5 text-sm" style={{ color: color }}>
                           <WikitextRenderer content={closedContent} mediaFiles={mediaFiles} />
                       </div>
                   </details>
               )
           }

           /* --- MUSIC TABBER (New) --- */

           if (templateName === 'MusicTabber') {
               const tracks: {title: string, url: string}[] = [];
               const style = args['style'];

               Object.keys(args).forEach(key => {
                   if (['style'].includes(key)) return;
                   // Assuming format: SongTitle = File:Song.mp3
                   if (isNaN(parseInt(key))) {
                       tracks.push({ title: key, url: findMediaUrl(args[key], mediaFiles) });
                   }
               });
               return <MusicTabber key={index} tracks={tracks} style={style} />
           }

           /* --- BATTLE RESULTS (New) --- */
           
           if (templateName === 'BattleResults') {
                return <BattleResults 
                    key={index}
                    wins={args['wins']}
                    draws={args['draws']}
                    losses={args['losses']}
                    style={args['style']}
                    borderColor={args['borderColor']}
                    textColor={args['textColor']}
                    bgColor={args['bgColor']}
                    mediaFiles={mediaFiles}
                />
           }

           /* --- ID TEMPLATES --- */

           if (templateName === 'IDV1') {
                const title = args['title'] || 'IDENTIFIER';
                const name = args['name'] || 'Unknown';
                const rank = args['rank'] || 'N/A';
                const image = findMediaUrl(args['image'], mediaFiles);
                const color = args['color'] || '#a855f7';
                
                return (
                    <div key={index} className="float-right ml-6 mb-4 w-72 bg-black border-2 relative overflow-hidden group shadow-lg z-10" style={{ borderColor: color }}>
                        <div className="absolute inset-0 bg-[linear-gradient(transparent_50%,rgba(0,0,0,0.5)_50%)] bg-[length:100%_4px] pointer-events-none opacity-20 z-20"></div>
                        <div className="bg-white/5 p-2 border-b" style={{ borderColor: color }}>
                            <div className="text-xs font-mono uppercase tracking-[0.2em] text-right" style={{ color: color }}>// {title} //</div>
                        </div>
                        <div className="relative h-64 overflow-hidden">
                            <img src={image} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" alt="ID" />
                            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black via-black/80 to-transparent">
                                <h3 className="text-2xl font-display font-bold text-white uppercase">{name}</h3>
                                <p className="text-sm font-mono" style={{ color: color }}>RANK: {rank}</p>
                            </div>
                        </div>
                    </div>
                );
           }

           if (templateName === 'IDV2') {
               const name = args['name'] || 'Name';
               const title = args['title'] || 'Title';
               const image = findMediaUrl(args['image'], mediaFiles);
               const glow = args['color'] || '#ffd700';

               return (
                   <div key={index} className="float-right ml-6 mb-4 w-72 relative z-10 group text-center">
                       <div className="absolute inset-0 blur-xl opacity-30 rounded-full" style={{ backgroundColor: glow }}></div>
                       <div className="relative z-10 border-4 double p-1 rounded-t-full rounded-b-lg bg-[#0a0505]" style={{ borderColor: glow }}>
                            <div className="h-64 rounded-t-full rounded-b-sm overflow-hidden border border-white/10">
                                <img src={image} className="w-full h-full object-cover" alt="Portrait" />
                            </div>
                            <div className="p-4 border-t border-white/10 mt-1">
                                <h3 className="font-serif text-2xl text-white font-bold tracking-widest">{name}</h3>
                                <div className="h-px w-12 mx-auto my-2" style={{ backgroundColor: glow }}></div>
                                <p className="text-xs uppercase tracking-widest text-gray-400">{title}</p>
                            </div>
                       </div>
                   </div>
               );
           }

           if (templateName === 'IDV3') {
               const name = args['name'] || 'NAME';
               const stats = args['stats'] || '';
               const image = findMediaUrl(args['image'], mediaFiles);
               const bg = args['bg'] || '#222';

               return (
                   <div key={index} className="float-right ml-6 mb-4 w-80 rounded-2xl overflow-hidden shadow-2xl relative z-10 group" style={{ background: bg }}>
                        <div className="h-48 overflow-hidden relative">
                            <img src={image} className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700" alt="Header" />
                            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
                            <div className="absolute bottom-4 left-4">
                                <h2 className="text-3xl font-black italic text-white tracking-tighter shadow-black drop-shadow-md">{name}</h2>
                            </div>
                        </div>
                        <div className="p-4 bg-white/5 backdrop-blur-sm">
                            <div className="text-sm text-gray-300 font-bold whitespace-pre-wrap">{stats}</div>
                        </div>
                   </div>
               );
           }

           if (templateName === 'Gallery') {
               const title = args['title'] || splitParts[1] || 'Gallery';
               const content = args['content'] || splitParts.slice(2).join('\n');
               const images: string[] = [];
               if (!args['content']) {
                    splitParts.forEach((p, i) => {
                        if(i > 1 && p.includes('File:')) images.push(p.trim());
                    });
               } else {
                   const matches = content.match(/File:[^|\n\]]+/g);
                   if (matches) matches.forEach(m => images.push(m));
               }

               return (
                   <details key={index} className="my-6 border border-white/10 rounded-xl overflow-hidden bg-black/20 group clear-both">
                       <summary className="p-4 bg-white/5 cursor-pointer font-bold text-lg flex items-center gap-2 hover:bg-white/10 transition-colors select-none">
                           <ImageIcon size={20} className="text-wom-primary" /> {title} <ChevronDown className="ml-auto transition-transform group-open:rotate-180" size={16} />
                       </summary>
                       <div className="p-4 grid grid-cols-2 md:grid-cols-3 gap-4">
                           {images.map((img, idx) => (
                               <div key={idx} className="bg-black border border-white/5 rounded-lg overflow-hidden p-1 hover:border-wom-primary transition-colors">
                                   <img 
                                        src={findMediaUrl(img, mediaFiles)} 
                                        className="w-full h-40 object-cover rounded hover:scale-105 transition-transform cursor-pointer" 
                                        alt="Gallery Item" 
                                        onClick={() => window.open(findMediaUrl(img, mediaFiles), '_blank')}
                                   />
                               </div>
                           ))}
                       </div>
                   </details>
               );
           }

           if (templateName === 'Spoiler' || templateName === 'SpoilerList') {
                const title = args['title'] || splitParts[1] || 'Spoiler';
                const content = args['content'] || splitParts.slice(2).join('|');
                return (
                    <details key={index} className="my-4 border-l-4 border-wom-primary bg-white/5 rounded-r-lg group clear-both">
                        <summary className="p-3 cursor-pointer font-bold flex items-center gap-2 text-wom-primary hover:text-white transition-colors">
                             <ChevronRight size={16} className="transition-transform group-open:rotate-90"/> {title}
                        </summary>
                        <div className="p-4 pt-0 text-sm text-gray-300">
                             <WikitextRenderer content={content} mediaFiles={mediaFiles} />
                        </div>
                    </details>
                );
           }

           if (templateName === 'Frame') {
                const title = args['title'] || splitParts[1];
                const content = args['content'] || splitParts[2];
                const iconName = args['icon'] || 'box';
                const borderColor = args['border'] || '#a855f7'; 
                const bg = args['bg'] || '#0f0a19';
                
                let IconComp = Box;
                if(iconName === 'shield') IconComp = Shield;
                if(iconName === 'zap') IconComp = Zap;
                if(iconName === 'skull') IconComp = Skull;
                if(iconName === 'crown') IconComp = Crown;

                return (
                    <div key={index} className="my-6 rounded-lg overflow-hidden border-2 shadow-lg clear-both" style={{ borderColor: borderColor, backgroundColor: bg }}>
                        {title && (
                            <div className="p-2 font-display font-bold text-white text-center uppercase tracking-widest flex items-center justify-center gap-2" style={{ backgroundColor: borderColor }}>
                                <IconComp size={18} /> {title}
                            </div>
                        )}
                        <div className="p-4 text-gray-300">
                             <WikitextRenderer content={content} mediaFiles={mediaFiles} />
                        </div>
                    </div>
                );
           }

           if (templateName === 'MessageBlock') {
               const type = (args['type'] || 'info').toLowerCase();
               const title = args['title'] || 'Notice';
               const text = args['text'] || splitParts[2] || '';
               
               let colors = 'bg-blue-900/20 border-blue-500/30 text-blue-200';
               let Icon = Info;
               
               if (type === 'warning') { colors = 'bg-orange-900/20 border-orange-500/30 text-orange-200'; Icon = AlertTriangle; }
               if (type === 'success') { colors = 'bg-green-900/20 border-green-500/30 text-green-200'; Icon = CheckCircle; }
               if (type === 'error') { colors = 'bg-red-900/20 border-red-500/30 text-red-200'; Icon = XCircle; }

               return (
                   <div key={index} className={`my-4 p-4 rounded-lg border flex gap-4 ${colors} clear-both`}>
                       <Icon className="shrink-0 mt-0.5" size={20} />
                       <div>
                           <div className="font-bold mb-1">{title}</div>
                           <div className="text-sm opacity-90"><WikitextRenderer content={text} mediaFiles={mediaFiles} /></div>
                       </div>
                   </div>
               );
           }

           return <span key={index} className="text-xs text-red-400 border border-red-900 px-1 rounded bg-red-900/10" title={inner}>Template Error: {templateName}</span>;
        } else {
           return <MarkdownBlock key={index} text={part} mediaFiles={mediaFiles} />;
        }
      })}
      
      <div className="clear-both table"></div>
    </div>
  );
}