export enum UserRole {
  USER = 'User',
  MODERATOR = 'Moderator',
  ADMIN = 'Admin'
}

export interface User {
  id: string;
  username: string;
  email?: string; 
  role: UserRole;
  avatar: string;
  banner?: string; 
  bio?: string;
  joinDate: string;
  watchlist?: string[]; 
}

export enum ArticleCategory {
  CHARACTER = 'Character',
  ABILITY = 'Ability',
  LOCATION = 'Location',
  ITEM = 'Item',
  TEMPLATE = 'Template'
}

export interface MediaItem {
  id: string;
  filename: string; 
  url: string; 
  uploaderId: string;
  timestamp: string;
  type: 'image' | 'video' | 'audio';
  size: number;
}

export interface Comment {
  id: string;
  authorId: string;
  content: string;
  timestamp: string;
  parentId?: string | null; 
  replies: Comment[];
}

export interface Article {
  id: string;
  slug: string;
  title: string;
  content: string; 
  category: ArticleCategory;
  authorId: string;
  lastEdited: string;
  imageUrl?: string;
  tags: string[];
  comments: Comment[];
}

export interface ColiseumThread {
  id: string;
  title: string;
  authorId: string;
  content: string; 
  timestamp: string;
  linkedArticleIds: string[]; 
  views: number;
  comments: Comment[];
}

export interface ChatMessage {
  id: string;
  senderId: string;
  content: string;
  timestamp: string;
  roomId: string; 
  type: 'text' | 'image' | 'system';
}

export interface Notification {
  id: string;
  userId: string;
  type: 'reply' | 'message' | 'system' | 'friend_request';
  content: string;
  read: boolean;
  timestamp: string;
  link?: string;
}

export interface WallPost {
  id: string;
  authorId: string;
  targetUserId: string;
  content: string;
  timestamp: string;
  comments: Comment[]; 
}

export interface WikiTemplate {
  name: string;
  content: string; 
  description: string;
}

export interface FriendRequest {
  id: string;
  senderId: string;
  receiverId: string;
  status: 'pending' | 'accepted';
  timestamp: string;
  sender?: User; // Hydrated for UI
}

export interface Friendship {
  friendId: string;
  friend: User;
  roomId: string; // The DM room ID
}